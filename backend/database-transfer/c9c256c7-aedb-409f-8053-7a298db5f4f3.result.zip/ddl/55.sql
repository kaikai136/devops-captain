CREATE TABLE `zt_burn` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `execution` int unsigned NOT NULL DEFAULT '0',
  `product` int unsigned NOT NULL DEFAULT '0',
  `task` int unsigned NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `estimate` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `left` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `consumed` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `storyPoint` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `execution_task` (`execution`,`date`,`task`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
