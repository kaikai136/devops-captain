CREATE TABLE `zt_demandspec` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `demand` int unsigned NOT NULL DEFAULT '0',
  `version` smallint unsigned NOT NULL DEFAULT '1',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `spec` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `verify` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `files` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `demand` (`demand`,`version`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
