CREATE TABLE `zt_charterproduct` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `charter` int unsigned NOT NULL DEFAULT '0',
  `product` int unsigned NOT NULL DEFAULT '0',
  `branch` int unsigned NOT NULL DEFAULT '0',
  `plan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `roadmap` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `charter_product` (`charter`,`product`,`branch`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
