CREATE TABLE `zt_approvalflowobject` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `root` int unsigned NOT NULL DEFAULT '0',
  `flow` int unsigned NOT NULL DEFAULT '0',
  `objectType` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `objectID` int unsigned NOT NULL DEFAULT '0',
  `extra` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
