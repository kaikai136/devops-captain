CREATE TABLE `zt_deployproduct` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `deploy` int unsigned NOT NULL DEFAULT '0',
  `product` int unsigned NOT NULL DEFAULT '0',
  `release` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `deploy_product_release` (`deploy`,`product`,`release`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
