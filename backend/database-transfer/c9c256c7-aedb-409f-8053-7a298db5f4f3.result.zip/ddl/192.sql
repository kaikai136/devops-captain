CREATE TABLE `zt_riskissue` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `risk` int unsigned NOT NULL DEFAULT '0',
  `issue` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `risk_issue` (`risk`,`issue`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
