CREATE TABLE `zt_config` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `vision` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `owner` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `section` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `key` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique` (`vision`,`owner`,`module`,`section`,`key`) USING BTREE,
  KEY `vision` (`vision`) USING BTREE,
  KEY `owner` (`owner`) USING BTREE,
  KEY `module` (`module`) USING BTREE,
  KEY `key` (`key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3135 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
