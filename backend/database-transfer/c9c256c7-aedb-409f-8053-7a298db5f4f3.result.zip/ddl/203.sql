CREATE TABLE `zt_sqlbuilder` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `objectID` int unsigned NOT NULL DEFAULT '0',
  `objectType` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sql` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `setting` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
