CREATE TABLE `xsy_calendar` (
  `kpi_day` date NOT NULL,
  `kpi_day_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '日历类型：0工作日 1法定节假日  2休息日'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
