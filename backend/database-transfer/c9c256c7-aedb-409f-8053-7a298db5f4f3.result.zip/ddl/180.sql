CREATE TABLE `zt_repobranch` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `repo` int unsigned NOT NULL DEFAULT '0',
  `revision` int unsigned NOT NULL DEFAULT '0',
  `branch` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `repo_revision_branch` (`repo`,`revision`,`branch`) USING BTREE,
  KEY `branch` (`branch`) USING BTREE,
  KEY `revision` (`revision`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
