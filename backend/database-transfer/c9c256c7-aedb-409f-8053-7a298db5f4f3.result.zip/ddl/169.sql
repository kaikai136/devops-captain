CREATE TABLE `zt_projectadmin` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `group` smallint unsigned NOT NULL DEFAULT '0',
  `account` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `programs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `projects` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `products` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `executions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `group_account` (`group`,`account`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
