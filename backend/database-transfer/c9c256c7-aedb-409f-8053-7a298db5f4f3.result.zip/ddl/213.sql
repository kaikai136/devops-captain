CREATE TABLE `zt_suitecase` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `suite` int unsigned NOT NULL DEFAULT '0',
  `product` int unsigned NOT NULL DEFAULT '0',
  `case` int unsigned NOT NULL DEFAULT '0',
  `version` smallint unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `suitecase` (`suite`,`case`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
