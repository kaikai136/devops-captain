CREATE TABLE `zt_testtaskproduct` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '编号',
  `product` int unsigned NOT NULL DEFAULT '0' COMMENT '所属产品',
  `build` int unsigned NOT NULL DEFAULT '0' COMMENT '所属构建',
  `task` int unsigned NOT NULL DEFAULT '0' COMMENT '所属测试单',
  `execution` int unsigned NOT NULL DEFAULT '0' COMMENT '所属执行',
  `project` int unsigned NOT NULL DEFAULT '0' COMMENT '所属项目',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_productbuild` (`product`,`build`,`task`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
