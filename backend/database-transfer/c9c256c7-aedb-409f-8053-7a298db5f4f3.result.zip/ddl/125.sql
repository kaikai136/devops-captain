CREATE TABLE `zt_kanbancell` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `kanban` int unsigned NOT NULL DEFAULT '0',
  `lane` int unsigned NOT NULL DEFAULT '0',
  `column` int unsigned NOT NULL DEFAULT '0',
  `type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cards` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `card_group` (`kanban`,`type`,`lane`,`column`) USING BTREE,
  KEY `lane` (`lane`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=837 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
