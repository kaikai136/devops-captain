CREATE TABLE `zt_ai_assistant` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modelId` int unsigned NOT NULL DEFAULT '0',
  `desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `systemMessage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `greetings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `icon` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'coding-1',
  `enabled` tinyint unsigned NOT NULL DEFAULT '1',
  `createdDate` datetime DEFAULT NULL,
  `publishedDate` datetime DEFAULT NULL,
  `deleted` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
