CREATE TABLE `zt_im_message_backup` (
  `id` int unsigned NOT NULL,
  `gid` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cgid` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  `index` int unsigned NOT NULL DEFAULT '0',
  `type` enum('normal','broadcast','notify') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `contentType` enum('text','plain','emotion','image','file','object','code') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
