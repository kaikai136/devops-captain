CREATE TABLE `zt_roadmapstory` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `roadmap` int unsigned NOT NULL DEFAULT '0',
  `story` int unsigned NOT NULL DEFAULT '0',
  `order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `roadmap_story` (`roadmap`,`story`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
