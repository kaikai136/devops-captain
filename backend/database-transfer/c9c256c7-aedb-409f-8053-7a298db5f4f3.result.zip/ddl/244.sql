CREATE TABLE `zt_workestimation` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `project` int unsigned NOT NULL DEFAULT '0',
  `scale` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `productivity` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `duration` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `unitLaborCost` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `totalLaborCost` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `createdBy` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `createdDate` datetime DEFAULT NULL,
  `editedBy` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `editedDate` datetime DEFAULT NULL,
  `assignedTo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `assignedDate` datetime DEFAULT NULL,
  `dayHour` decimal(10,2) NOT NULL DEFAULT '0.00',
  `deleted` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
