CREATE TABLE `zt_weeklyreport` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `project` int unsigned NOT NULL DEFAULT '0',
  `weekStart` date DEFAULT NULL,
  `pv` decimal(12,2) unsigned NOT NULL DEFAULT '0.00',
  `ev` decimal(12,2) unsigned NOT NULL DEFAULT '0.00',
  `ac` decimal(12,2) unsigned NOT NULL DEFAULT '0.00',
  `sv` decimal(12,2) NOT NULL DEFAULT '0.00',
  `cv` decimal(12,2) NOT NULL DEFAULT '0.00',
  `staff` smallint unsigned NOT NULL DEFAULT '0',
  `progress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `workload` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `week` (`project`,`weekStart`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
