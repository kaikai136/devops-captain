CREATE TABLE `zt_im_userdevice` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT,
  `user` mediumint NOT NULL DEFAULT '0',
  `device` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `deviceID` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `token` char(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `validUntil` datetime DEFAULT NULL,
  `lastLogin` datetime DEFAULT NULL,
  `lastLogout` datetime DEFAULT NULL,
  `online` tinyint(1) NOT NULL DEFAULT '0',
  `version` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `userdevice` (`user`,`device`) USING BTREE,
  KEY `user` (`user`) USING BTREE,
  KEY `lastLogin` (`lastLogin`) USING BTREE,
  KEY `lastLogout` (`lastLogout`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
