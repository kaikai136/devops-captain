CREATE TABLE `zt_taskestimate` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `task` int unsigned NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `left` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `consumed` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `account` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `work` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `task` (`task`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
