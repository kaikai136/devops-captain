CREATE TABLE `zt_im_conferenceaction` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT,
  `rid` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` enum('create','invite','join','leave','close','publish') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'create',
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `user` mediumint NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `device` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
