CREATE TABLE `zt_storyestimate` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `story` int unsigned NOT NULL DEFAULT '0',
  `round` smallint unsigned NOT NULL DEFAULT '0',
  `estimate` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `average` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `openedBy` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `openedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `story` (`story`,`round`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
