CREATE TABLE `zt_planstory` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `plan` int unsigned NOT NULL DEFAULT '0',
  `story` int unsigned NOT NULL DEFAULT '0',
  `order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `plan_story` (`plan`,`story`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
