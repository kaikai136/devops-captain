CREATE TABLE `zt_searchindex` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `objectType` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `objectID` int unsigned NOT NULL DEFAULT '0',
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `addedDate` datetime DEFAULT NULL,
  `editedDate` datetime DEFAULT NULL,
  `vision` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'rnd',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `object` (`objectType`,`objectID`) USING BTREE,
  KEY `addedDate` (`addedDate`) USING BTREE,
  FULLTEXT KEY `title_content` (`title`,`content`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
