CREATE TABLE `xsy_group_evaluation` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `rater` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '评分人（用户名）',
  `ratee` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '被评分人（用户名）',
  `score` int NOT NULL COMMENT '评分（1-10分）',
  `month` varchar(7) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '评分月份（格式：YYYY-MM）',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `update_time` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_rater_ratee_month` (`rater`,`ratee`,`month`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='小组互评表';
