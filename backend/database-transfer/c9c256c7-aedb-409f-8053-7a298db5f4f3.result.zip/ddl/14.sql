CREATE TABLE `zt_actionproduct` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `action` int unsigned NOT NULL DEFAULT '0',
  `product` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `action_product` (`action`,`product`) USING BTREE,
  KEY `product` (`product`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=527 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
