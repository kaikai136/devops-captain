CREATE TABLE `zt_history` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `action` int unsigned NOT NULL DEFAULT '0',
  `field` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `old` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `oldValue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `new` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `newValue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `diff` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `action` (`action`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=308 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
