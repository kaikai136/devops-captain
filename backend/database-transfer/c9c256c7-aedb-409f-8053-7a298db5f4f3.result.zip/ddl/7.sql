CREATE TABLE `xsy_leave` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '请假记录ID',
  `user_code` char(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '登记人ID',
  `leave_date_begin` date NOT NULL COMMENT '请假开始日期',
  `leave_date_end` date NOT NULL COMMENT '请假结束日期',
  `leave_type` tinyint NOT NULL COMMENT '请假类型(1-年假,2-病假,3-事假,4-调休,5-其他)',
  `total_hours` decimal(5,2) NOT NULL COMMENT '请假时长(小时)',
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备注信息',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint DEFAULT '0' COMMENT '逻辑删除标记(0-未删除,1-已删除)',
  `create_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '登记人（用户登录账号）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=294 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='请假登记表';
