CREATE TABLE `zt_ai_miniprogramstar` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `appID` int unsigned NOT NULL DEFAULT '0',
  `userID` int unsigned NOT NULL DEFAULT '0',
  `createdDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_appUser` (`appID`,`userID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
