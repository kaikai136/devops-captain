CREATE TABLE `tmp_task_getProjectTasks` (
  `consumed` decimal(32,2) DEFAULT NULL,
  `project` int unsigned NOT NULL DEFAULT '0',
  KEY `project` (`project`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
