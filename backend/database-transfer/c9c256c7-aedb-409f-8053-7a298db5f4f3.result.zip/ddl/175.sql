CREATE TABLE `zt_relation` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `project` int unsigned NOT NULL DEFAULT '0',
  `product` int unsigned NOT NULL DEFAULT '0',
  `execution` int unsigned NOT NULL DEFAULT '0',
  `AType` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `AID` int unsigned NOT NULL DEFAULT '0',
  `AVersion` smallint unsigned NOT NULL DEFAULT '1',
  `relation` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `BType` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `BID` int unsigned NOT NULL DEFAULT '0',
  `BVersion` smallint unsigned NOT NULL DEFAULT '1',
  `extra` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `relation` (`product`,`relation`,`AType`,`BType`,`AID`,`BID`) USING BTREE,
  KEY `AID` (`AType`,`AID`) USING BTREE,
  KEY `BID` (`BType`,`BID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
