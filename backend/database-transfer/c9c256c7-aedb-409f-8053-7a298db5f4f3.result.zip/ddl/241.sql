CREATE TABLE `zt_userview` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `programs` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `products` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `projects` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sprints` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `account` (`account`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
