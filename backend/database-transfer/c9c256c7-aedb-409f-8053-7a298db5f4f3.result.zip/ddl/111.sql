CREATE TABLE `zt_im_conferenceuser` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT,
  `conference` mediumint NOT NULL DEFAULT '0',
  `user` mediumint NOT NULL DEFAULT '0',
  `hide` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `conferenceuser` (`conference`,`user`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
