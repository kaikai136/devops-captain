CREATE TABLE `zt_ticketrelation` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ticketId` int unsigned NOT NULL DEFAULT '0',
  `objectId` int unsigned NOT NULL DEFAULT '0',
  `objectType` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `ticketId` (`ticketId`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
