CREATE TABLE `tmp_case_getDevStories` (
  `story` int unsigned NOT NULL DEFAULT '0',
  `case_count` bigint NOT NULL DEFAULT '0',
  `ip` text COLLATE utf8mb4_unicode_ci,
  KEY `story` (`story`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
