CREATE TABLE `zt_storyspec` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `story` int unsigned NOT NULL DEFAULT '0',
  `version` smallint unsigned NOT NULL DEFAULT '1',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `spec` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `verify` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `files` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `docs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `docVersions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `story` (`story`,`version`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
