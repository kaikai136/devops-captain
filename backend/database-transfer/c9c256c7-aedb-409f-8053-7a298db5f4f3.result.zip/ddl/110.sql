CREATE TABLE `zt_im_conferenceinvite` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT,
  `conferenceID` mediumint unsigned NOT NULL,
  `inviteeID` mediumint unsigned NOT NULL,
  `status` enum('pending','accepted','rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `createdDate` datetime DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `conference_user` (`conferenceID`,`inviteeID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
