CREATE TABLE `zt_faq` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `module` int unsigned NOT NULL DEFAULT '0',
  `product` int unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `answer` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `addedtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
