CREATE TABLE `xsy_overtime` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '加班记录ID',
  `user_code` char(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '登记人编号',
  `overtime_date` date NOT NULL COMMENT '加班日期',
  `duration` decimal(5,2) NOT NULL COMMENT '加班时长(小时)',
  `reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加班原因',
  `create_user` char(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint DEFAULT '0' COMMENT '逻辑删除标记(0-未删除,1-已删除)',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_user_id` (`user_code`) USING BTREE,
  KEY `idx_overtime_date` (`overtime_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='加班登记表';
