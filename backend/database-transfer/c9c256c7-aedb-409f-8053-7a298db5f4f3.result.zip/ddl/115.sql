CREATE TABLE `zt_im_messagestatus` (
  `user` mediumint NOT NULL DEFAULT '0',
  `message` int unsigned NOT NULL,
  `status` enum('waiting','sent','readed','deleted') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'waiting',
  UNIQUE KEY `user` (`user`,`message`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
