CREATE TABLE `zt_im_message` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `gid` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cgid` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  `index` int unsigned NOT NULL DEFAULT '0',
  `type` enum('normal','broadcast','notify','bulletin','botcommand') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `contentType` enum('text','plain','emotion','image','file','object','code','merge','voice') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `deleted` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `read` json DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `mgid` (`gid`) USING BTREE,
  KEY `mcgid` (`cgid`) USING BTREE,
  KEY `muser` (`user`) USING BTREE,
  KEY `mtype` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
