CREATE TABLE `zt_taskteam` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `task` int unsigned NOT NULL DEFAULT '0',
  `account` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `estimate` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `consumed` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `left` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `transfer` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'wait',
  `storyVersion` smallint unsigned NOT NULL DEFAULT '1',
  `order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `task` (`task`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
