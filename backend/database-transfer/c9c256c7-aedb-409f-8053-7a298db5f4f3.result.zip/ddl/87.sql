CREATE TABLE `zt_duckdbqueue` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `object` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `updatedTime` datetime DEFAULT NULL,
  `syncTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `object` (`object`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
