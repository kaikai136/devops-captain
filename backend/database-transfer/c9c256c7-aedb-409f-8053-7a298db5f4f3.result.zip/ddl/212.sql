CREATE TABLE `zt_storystage` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `story` int unsigned NOT NULL DEFAULT '0',
  `branch` int unsigned NOT NULL DEFAULT '0',
  `stage` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `stagedBy` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `story_branch` (`story`,`branch`) USING BTREE,
  KEY `story` (`story`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
