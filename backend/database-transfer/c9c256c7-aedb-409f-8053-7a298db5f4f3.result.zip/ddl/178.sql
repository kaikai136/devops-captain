CREATE TABLE `zt_releaserelated` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `release` int unsigned NOT NULL DEFAULT '0',
  `objectID` int unsigned NOT NULL DEFAULT '0',
  `objectType` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `unique` (`release`,`objectID`,`objectType`) USING BTREE,
  KEY `objectID` (`objectID`) USING BTREE,
  KEY `objectType` (`objectType`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
