CREATE TABLE `zt_queue` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `cron` int unsigned NOT NULL DEFAULT '0',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `command` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'wait',
  `execId` int unsigned NOT NULL DEFAULT '0',
  `createdDate` datetime DEFAULT NULL,
  `deleted` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status_createdDate` (`status`,`createdDate`) USING BTREE,
  KEY `cron_createdDate` (`cron`,`createdDate`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=103285 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
