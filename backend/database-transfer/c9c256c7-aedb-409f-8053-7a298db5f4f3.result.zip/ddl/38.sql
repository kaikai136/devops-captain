CREATE TABLE `zt_approvalobject` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `approval` int unsigned NOT NULL DEFAULT '0',
  `objectType` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `objectID` int unsigned NOT NULL DEFAULT '0',
  `reviewers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `opinion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `result` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `appliedBy` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `appliedDate` datetime DEFAULT NULL,
  `desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `extra` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
