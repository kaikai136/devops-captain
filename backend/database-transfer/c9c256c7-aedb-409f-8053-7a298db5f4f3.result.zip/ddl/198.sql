CREATE TABLE `zt_searchdict` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `key` smallint unsigned NOT NULL DEFAULT '0',
  `value` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `key_value` (`key`,`value`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=511 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
