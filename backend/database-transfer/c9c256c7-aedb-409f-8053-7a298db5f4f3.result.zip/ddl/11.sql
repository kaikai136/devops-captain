CREATE TABLE `xsy_user_salary` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `account` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户账号',
  `salary1` varbinary(255) NOT NULL COMMENT '加密存储的薪水（AES加密）指人天成本',
  `salary2` varbinary(255) NOT NULL COMMENT '加密存储的薪水（AES加密）指平摊后人天成本',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `account` (`account`) USING BTREE,
  KEY `idx_user_account` (`account`) USING BTREE COMMENT '用户账号索引'
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户薪水表（含加密字段）';
