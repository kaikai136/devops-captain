CREATE TABLE `zt_kanbangroup` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `kanban` int unsigned NOT NULL DEFAULT '0',
  `region` int unsigned NOT NULL DEFAULT '0',
  `order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
