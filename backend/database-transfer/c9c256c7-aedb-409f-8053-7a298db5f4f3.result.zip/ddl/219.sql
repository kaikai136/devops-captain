CREATE TABLE `zt_team` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `root` int unsigned NOT NULL DEFAULT '0',
  `type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'project',
  `account` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `role` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `position` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `limited` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `join` date DEFAULT NULL,
  `days` smallint unsigned NOT NULL DEFAULT '0',
  `hours` decimal(3,1) unsigned NOT NULL DEFAULT '0.0',
  `estimate` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `consumed` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `left` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `order` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `team` (`root`,`type`,`account`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=802 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
