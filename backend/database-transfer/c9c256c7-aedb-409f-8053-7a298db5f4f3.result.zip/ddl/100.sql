CREATE TABLE `zt_grouppriv` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `group` int unsigned NOT NULL DEFAULT '0',
  `module` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `method` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `group` (`group`,`module`,`method`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24595 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
