CREATE TABLE `zt_ai_agentfield` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `appID` int unsigned NOT NULL COMMENT '所属 Prompt 的 ID，对应 zt_ai_agent.id',
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '字段名称',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text' COMMENT '字段类型',
  `placeholder` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '输入提示',
  `options` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '选项列表，逗号分隔',
  `required` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '是否必填',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
