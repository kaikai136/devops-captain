CREATE TABLE `zt_docaction` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `doc` int unsigned NOT NULL DEFAULT '0',
  `action` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `actor` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `doc` (`doc`) USING BTREE,
  KEY `actor` (`actor`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
